#!/bin/bash

# 快速启动
./"Lamina-iOS-CPP-1.1.1-Beta"