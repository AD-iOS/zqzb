#!/bin/bash

# 快速启动
cd /var/jb/AD/Lamina
./Start.sh