#!/bin/bash

# ========================
# 用户界面
# ========================

show_main_menu() {
    clear
    echo -e "${CYAN}"
    echo "iOS越狱DEB生成工具 v7.0"
    echo "开发者: AD | QQ: 3897069329"
    echo -e "${BLUE}=============================================${NC}"
    echo -e "${GREEN}           无根越狱项目 (现代越狱)           ${NC}"
    echo -e "${GREEN}1. 创建无根应用 (/var/jb/Applications)      ${NC}"
    echo -e "${GREEN}2. 创建无根插件 (/var/jb/Library/MobileSubstrate)${NC}"
    echo -e "${GREEN}3. 创建无根主题 (/var/jb/Library/Themes)    ${NC}"
    echo -e "${GREEN}4. 创建无根工具 (/var/jb/usr/bin)           ${NC}"
    echo -e "${GREEN}5. 创建无根偏好设置 (/var/jb/Library/PreferenceBundles)${NC}"
    echo -e "${GREEN}6. 创建无根字体包 (/var/jb/Library/Fonts)   ${NC}"
    echo -e "${GREEN}7. 创建无根守护进程 (/var/jb/Library/LaunchDaemons)${NC}"
    echo -e "${GREEN}8. 创建无根Emoji字体 (/var/jb/Library/Fonts)${NC}"
    echo -e "${GREEN}9. 创建无根状态栏主题 (/var/jb/Library/StatusBar)${NC}"
    echo -e "${GREEN}10. 创建无根键盘主题 (/var/jb/Library/Keyboard)${NC}"
    echo -e "${GREEN}11. 创建无根音效包 (/var/jb/Library/Sounds)${NC}"
    echo -e "${GREEN}12. 创建无根壁纸包 (/var/jb/Library/Wallpaper)${NC}"
    echo -e "${GREEN}13. 创建无根控制中心模块 (/var/jb/Library/ControlCenter)${NC}"
    echo -e "${GREEN}14. 创建无根通知中心组件 (/var/jb/Library/TodayView)${NC}"
    echo -e "${GREEN}15. 创建纯无根DEB (仅基础结构)              ${NC}"
    echo -e "${BLUE}---------------------------------------------${NC}"
    echo -e "${YELLOW}           有根越狱项目 (传统越狱)           ${NC}"
    echo -e "${YELLOW}16. 创建有根应用 (/Applications)            ${NC}"
    echo -e "${YELLOW}17. 创建有根插件 (/Library/MobileSubstrate) ${NC}"
    echo -e "${YELLOW}18. 创建有根主题 (/Library/Themes)          ${NC}"
    echo -e "${YELLOW}19. 创建有根工具 (/usr/bin)                 ${NC}"
    echo -e "${YELLOW}20. 创建有根偏好设置 (/Library/PreferenceBundles)${NC}"
    echo -e "${YELLOW}21. 创建有根字体包 (/Library/Fonts)         ${NC}"
    echo -e "${YELLOW}22. 创建有根守护进程 (/Library/LaunchDaemons)${NC}"
    echo -e "${YELLOW}23. 创建有根Emoji字体 (/Library/Fonts)      ${NC}"
    echo -e "${YELLOW}24. 创建有根状态栏主题 (/Library/StatusBar) ${NC}"
    echo -e "${YELLOW}25. 创建有根键盘主题 (/Library/Keyboard)    ${NC}"
    echo -e "${YELLOW}26. 创建有根音效包 (/Library/Sounds)        ${NC}"
    echo -e "${YELLOW}27. 创建有根壁纸包 (/Library/Wallpaper)     ${NC}"
    echo -e "${YELLOW}28. 创建有根控制中心模块 (/Library/ControlCenter)${NC}"
    echo -e "${YELLOW}29. 创建有根通知中心组件 (/Library/TodayView)${NC}"
    echo -e "${YELLOW}30. 创建纯有根DEB (仅基础结构)             ${NC}"
    echo -e "${BLUE}---------------------------------------------${NC}"
    echo -e "${CYAN}31. 项目管理                                ${NC}"
    echo -e "${CYAN}32. 查看开发指南                            ${NC}"
    echo -e "${CYAN}33. 清理缓存                                ${NC}"
    echo -e "${RED}0. 退出程序                                 ${NC}"
    echo -e "${BLUE}=============================================${NC}"

    read -p "请输入选项数字: " choice
    case ${choice} in
        1) create_deb_structure "rootless-app" ;;
        2) create_deb_structure "rootless-tweak" ;;
        3) create_deb_structure "rootless-theme" ;;
        4) create_deb_structure "rootless-tool" ;;
        5) create_deb_structure "rootless-prefs" ;;
        6) create_deb_structure "rootless-font" ;;
        7) create_deb_structure "rootless-daemon" ;;
        8) create_deb_structure "rootless-emoji" ;;
        9) create_deb_structure "rootless-statusbar" ;;
        10) create_deb_structure "rootless-keyboard" ;;
        11) create_deb_structure "rootless-sound" ;;
        12) create_deb_structure "rootless-wallpaper" ;;
        13) create_deb_structure "rootless-ccmodule" ;;
        14) create_deb_structure "rootless-today" ;;
        15) create_deb_structure "pure-rootless" ;;
        16) create_deb_structure "rooted-app" ;;
        17) create_deb_structure "rooted-tweak" ;;
        18) create_deb_structure "rooted-theme" ;;
        19) create_deb_structure "rooted-tool" ;;
        20) create_deb_structure "rooted-prefs" ;;
        21) create_deb_structure "rooted-font" ;;
        22) create_deb_structure "rooted-daemon" ;;
        23) create_deb_structure "rooted-emoji" ;;
        24) create_deb_structure "rooted-statusbar" ;;
        25) create_deb_structure "rooted-keyboard" ;;
        26) create_deb_structure "rooted-sound" ;;
        27) create_deb_structure "rooted-wallpaper" ;;
        28) create_deb_structure "rooted-ccmodule" ;;
        29) create_deb_structure "rooted-today" ;;
        30) create_deb_structure "pure-rooted" ;;
        31) manage_projects ;;
        32) 
            [ -f "${TUTORIAL_FILE}" ] && less "${TUTORIAL_FILE}" || {
                create_tutorial
                less "${TUTORIAL_FILE}"
            }
            ;;
        33)
            rm -rf "${CACHE_DIR}"/*.version
            rm -f "${LOG_DIR}"/*.log
            log "INFO" "${GREEN}✅ 缓存已清理${NC}"
            ;;
        0)
            log "INFO" "${GREEN}感谢使用！开发者: AD | QQ: 3897069329${NC}"
            exit 0
            ;;
        *)
            log "ERROR" "${RED}无效输入，请重新选择${NC}"
            sleep 1
            ;;
    esac

    read -n 1 -s -r -p "按任意键返回主菜单..."
    show_main_menu
}
