#!/bin/bash

# 快速启动
cd /var/jb/AD/AD-deb
source ./Start.sh