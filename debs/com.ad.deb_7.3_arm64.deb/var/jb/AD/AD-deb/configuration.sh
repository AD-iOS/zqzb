#!/bin/bash

# ========================
# 动态化配置（会被Start.sh覆盖）
# ========================
CONFIG_DIR="${CONFIG_DIR:-deb_config}"          # Start.sh会动态设置
LOG_DIR="${LOG_DIR:-${CONFIG_DIR}/logs}"        # 默认值，可被覆盖
TEMPLATES_DIR="${TEMPLATES_DIR:-${CONFIG_DIR}/templates}"
PROJECTS_DIR="${PROJECTS_DIR:-DEB_Projects}"
CACHE_DIR="${CACHE_DIR:-${CONFIG_DIR}/cache}"

# 日志文件
MAIN_LOG="${LOG_DIR}/main.log"
ERROR_LOG="${LOG_DIR}/error.log"
DEBUG_LOG="${LOG_DIR}/debug.log"

# 颜色定义（不变）
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; PURPLE='\033[0;35m'
NC='\033[0m'