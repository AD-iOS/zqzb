#!/bin/bash

check_dependencies() {
    local project_dir="$1"
    local control_file="${project_dir}/DEBIAN/control"
    
    if [ ! -f "${control_file}" ]; then
        log "WARN" "${YELLOW}⚠️ 找不到control文件，无法检查依赖${NC}"
        return
    fi
    
    local depends_line=$(grep -i "^Depends:" "${control_file}")
    if [ -z "${depends_line}" ]; then
        log "INFO" "${GREEN}✅ 该项目没有依赖要求${NC}"
        return
    fi
    
    local depends=${depends_line#Depends: }
    log "INFO" "${CYAN}检查依赖: ${depends}${NC}"
    
    # 这里可以添加更复杂的依赖检查逻辑
    # 目前只是显示信息
    echo -e "${YELLOW}请手动确保以下依赖已安装:${NC}"
    echo -e "${depends}" | tr ',' '\n' | sed 's/^ //' | sed 's/ $//'
    echo ""
}
