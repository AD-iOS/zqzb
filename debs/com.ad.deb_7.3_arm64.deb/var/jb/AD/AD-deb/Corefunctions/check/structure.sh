#!/bin/bash

check_project_structure() {
    local project_dir="$1"
    local project_name=$(basename "${project_dir}")
    
    echo -e "${CYAN}"
    echo "检查项目结构: ${project_name}"
    echo "---------------------------------------------"
    
    # 检查基本DEBIAN文件
    echo -e "${BLUE}[基本检查]${NC}"
    if [ -f "${project_dir}/DEBIAN/control" ]; then
        echo -e "${GREEN}✅ control文件存在${NC}"
    else
        echo -e "${RED}❌ 缺少control文件${NC}"
    fi
    
    if [ -f "${project_dir}/DEBIAN/postinst" ]; then
        echo -e "${GREEN}✅ postinst脚本存在${NC}"
        if [ -x "${project_dir}/DEBIAN/postinst" ]; then
            echo -e "${GREEN}✅ postinst可执行${NC}"
        else
            echo -e "${YELLOW}⚠️ postinst不可执行 (请运行 chmod 755)${NC}"
        fi
    else
        echo -e "${YELLOW}⚠️ 缺少postinst脚本${NC}"
    fi
    
    # 根据项目类型检查特定文件
    echo -e "${BLUE}[类型特定检查]${NC}"
    case "${project_name}" in
        *-tweak*|*-statusbar*|*-ccmodule*|*-today*)
            if [[ "${project_name}" == rootless-* ]]; then
                local dylib_path="var/jb/Library/MobileSubstrate/DynamicLibraries"
            else
                local dylib_path="Library/MobileSubstrate/DynamicLibraries"
            fi
            
            if [ -f "${project_dir}/${dylib_path}/${project_name#*-}.dylib" ]; then
                echo -e "${GREEN}✅ dylib文件存在${NC}"
            else
                echo -e "${YELLOW}⚠️ 缺少dylib文件${NC}"
            fi
            
            if [ -f "${project_dir}/${dylib_path}/${project_name#*-}.plist" ]; then
                echo -e "${GREEN}✅ plist过滤器存在${NC}"
            else
                echo -e "${YELLOW}⚠️ 缺少plist过滤器${NC}"
            fi
            ;;
        *-app*)
            if [[ "${project_name}" == rootless-* ]]; then
                local app_path="var/jb/Applications"
            else
                local app_path="Applications"
            fi
            
            if [ -d "${project_dir}/${app_path}/${project_name#*-}.app" ]; then
                echo -e "${GREEN}✅ .app目录存在${NC}"
                if [ -f "${project_dir}/${app_path}/${project_name#*-}.app/Info.plist" ]; then
                    echo -e "${GREEN}✅ Info.plist存在${NC}"
                else
                    echo -e "${YELLOW}⚠️ 缺少Info.plist${NC}"
                fi
            else
                echo -e "${YELLOW}⚠️ 缺少.app目录${NC}"
            fi
            ;;
        *-theme*)
            if [[ "${project_name}" == rootless-* ]]; then
                local theme_path="var/jb/Library/Themes"
            else
                local theme_path="Library/Themes"
            fi
            
            if [ -d "${project_dir}/${theme_path}/${project_name#*-}.theme" ]; then
                echo -e "${GREEN}✅ 主题目录存在${NC}"
            else
                echo -e "${YELLOW}⚠️ 缺少主题目录${NC}"
            fi
            ;;
        *-font*|*-emoji*)
            if [[ "${project_name}" == rootless-* ]]; then
                local font_path="var/jb/Library/Fonts"
            else
                local font_path="Library/Fonts"
            fi
            
            if [ -d "${project_dir}/${font_path}/${project_name#*-}" ]; then
                echo -e "${GREEN}✅ 字体目录存在${NC}"
                local font_count=$(find "${project_dir}/${font_path}/${project_name#*-}" -type f \( -name "*.ttf" -o -name "*.otf" -o -name "*.ttc" \) | wc -l)
                if [ $font_count -gt 0 ]; then
                    echo -e "${GREEN}✅ 找到 ${font_count} 个字体文件${NC}"
                else
                    echo -e "${YELLOW}⚠️ 字体目录中没有字体文件${NC}"
                fi
            else
                echo -e "${YELLOW}⚠️ 缺少字体目录${NC}"
            fi
            ;;
        *-daemon*)
            if [[ "${project_name}" == rootless-* ]]; then
                local daemon_path="var/jb/Library/LaunchDaemons"
                local bin_path="var/jb/usr/bin"
            else
                local daemon_path="Library/LaunchDaemons"
                local bin_path="usr/bin"
            fi
            
            if [ -f "${project_dir}/${daemon_path}/${project_name#*-}.plist" ]; then
                echo -e "${GREEN}✅ launchd plist文件存在${NC}"
            else
                echo -e "${YELLOW}⚠️ 缺少launchd plist文件${NC}"
            fi
            
            if [ -f "${project_dir}/${bin_path}/${project_name#*-}" ]; then
                echo -e "${GREEN}✅ 二进制文件存在${NC}"
                if [ -x "${project_dir}/${bin_path}/${project_name#*-}" ]; then
                    echo -e "${GREEN}✅ 二进制文件可执行${NC}"
                else
                    echo -e "${YELLOW}⚠️ 二进制文件不可执行 (请运行 chmod 755)${NC}"
                fi
            else
                echo -e "${YELLOW}⚠️ 缺少二进制文件${NC}"
            fi
            ;;
        *-sound*)
            if [[ "${project_name}" == rootless-* ]]; then
                local sound_path="var/jb/Library/Sounds"
            else
                local sound_path="Library/Sounds"
            fi
            
            if [ -d "${project_dir}/${sound_path}" ]; then
                echo -e "${GREEN}✅ 音效目录存在${NC}"
                local sound_count=$(find "${project_dir}/${sound_path}" -type f \( -name "*.caf" -o -name "*.m4a" \) | wc -l)
                if [ $sound_count -gt 0 ]; then
                    echo -e "${GREEN}✅ 找到 ${sound_count} 个音效文件${NC}"
                else
                    echo -e "${YELLOW}⚠️ 音效目录中没有音效文件${NC}"
                fi
            else
                echo -e "${YELLOW}⚠️ 缺少音效目录${NC}"
            fi
            ;;
        *-wallpaper*)
            if [[ "${project_name}" == rootless-* ]]; then
                local wall_path="var/jb/Library/Wallpaper"
            else
                local wall_path="Library/Wallpaper"
            fi
            
            if [ -d "${project_dir}/${wall_path}" ]; then
                echo -e "${GREEN}✅ 壁纸目录存在${NC}"
                local wall_count=$(find "${project_dir}/${wall_path}" -type f \( -name "*.png" -o -name "*.jpg" \) | wc -l)
                if [ $wall_count -gt 0 ]; then
                    echo -e "${GREEN}✅ 找到 ${wall_count} 张壁纸${NC}"
                else
                    echo -e "${YELLOW}⚠️ 壁纸目录中没有壁纸文件${NC}"
                fi
            else
                echo -e "${YELLOW}⚠️ 缺少壁纸目录${NC}"
            fi
            ;;
    esac
    
    echo "---------------------------------------------"
    echo -e "${NC}"
    read -n 1 -s -r -p "按任意键继续..."
}