#!/bin/bash

create_tutorial() {
    cat > "${TUTORIAL_FILE}" <<'EOF'
# ========================
# iOS越狱DEB开发完整指南 v4.0
# ========================

1. 路径说明：
   ● 有根越狱(传统):
     /Applications 
     /Library/MobileSubstrate
     /Library/Themes
     /Library/Fonts
     /usr/bin
     /System/Library/PreferenceBundles
     /Library/LaunchDaemons
     /System/Library/Fonts/Core (Emoji字体)

   ● 无根越狱(现代):
     /var/jb/Applications
     /var/jb/Library/MobileSubstrate
     /var/jb/Library/Themes
     /var/jb/Library/Fonts
     /var/jb/usr/bin
     /var/jb/System/Library/PreferenceBundles
     /var/jb/Library/LaunchDaemons
     /var/jb/System/Library/Fonts/Core (Emoji字体)

2. 新增DEB类型支持：
   ● 系统服务(LaunchDaemon) - 后台运行的服务
   ● Emoji字体替换 - 替换系统Emoji字体
   ● 状态栏主题 - 修改状态栏样式
   ● 键盘主题 - 修改键盘外观
   ● 系统音效 - 替换系统提示音
   ● 壁纸包 - 打包多张壁纸
   ● 语言包 - 添加/修改系统语言
   ● 动态壁纸 - 添加动态壁纸
   ● 控制中心模块 - 添加CC模块
   ● 通知中心组件 - 添加Today插件

3. control文件规范：
Package: com.公司.插件名
Name: 插件显示名称
Version: 1.0
Architecture: iphoneos-arm
Description: 插件功能描述
Maintainer: 维护者 <邮箱@example.com>
Author: 作者 <邮箱@example.com>
Section: Tweaks
Depends: firmware (>= 15.0), mobilesubstrate
Priority: optional
Homepage: https://example.com

4. 新增功能：
   ● 支持系统服务创建
   ● 支持Emoji字体替换
   ● 支持状态栏主题
   ● 支持键盘主题
   ● 支持系统音效替换
   ● 支持壁纸包创建
   ● 支持语言包安装
   ● 支持动态壁纸
   ● 支持控制中心模块
   ● 支持通知中心组件
   ● 增强的依赖检查
   ● 自动版本号递增
   ● 项目结构验证

5. 高级技巧：
   ● 使用ldid签名二进制文件
   ● 使用otool检查依赖项
   ● 使用THEOS开发框架
   ● 使用logify注入日志
   ● 使用flexdecrypt解密二进制
   ● 使用frida进行动态分析
   ● 使用cycript进行运行时调试
EOF

    log "INFO" "${GREEN}✅ 教程文件已创建: ${TUTORIAL_FILE}${NC}"
}
