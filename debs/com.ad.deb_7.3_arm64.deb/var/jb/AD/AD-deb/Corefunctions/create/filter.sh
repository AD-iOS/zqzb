#!/bin/bash

create_plist_filter() {
    local project_dir="$1"
    local project_name="$2"
    local project_type="$3"
    
    if [[ "${project_type}" == *-tweak* ]] || [[ "${project_type}" == *-statusbar* ]] || [[ "${project_type}" == *-ccmodule* ]]; then
        local plist_path=""
        if [[ "${project_type}" == rootless-* ]]; then
            plist_path="${project_dir}/var/jb/Library/MobileSubstrate/DynamicLibraries/${project_name}.plist"
        else
            plist_path="${project_dir}/Library/MobileSubstrate/DynamicLibraries/${project_name}.plist"
        fi
        
        cp "${TEMPLATES_DIR}/filter.tpl" "${plist_path}"
        log "INFO" "${GREEN}✅ 已创建注入过滤器: $(basename "${plist_path}")${NC}"
        
        # 提供编辑选项
        read -p "是否要编辑过滤器文件? (y/n) [n]: " edit_choice
        if [[ "${edit_choice}" =~ [yY] ]]; then
            edit_plist_file "${plist_path}"
        fi
    fi
}
