#!/bin/bash

create_deb_structure() {
    local project_type="$1"
    
    case ${project_type} in
        *-font*)
            create_font_project "${project_type}"
            return
            ;;
        *-emoji*)
            create_emoji_project "${project_type}"
            return
            ;;
        *-daemon*)
            create_daemon_project "${project_type}"
            return
            ;;
    esac
    
    local project_name=""
    
    # 验证项目ID格式
    while true; do
        read -p "请输入项目ID (例如 com.公司.插件名): " project_name
        if validate_project_name "${project_name}"; then
            break
        fi
    done

    local base_dir="${PROJECTS_DIR}/${project_type}_${project_name}"
    local debian_dir="${base_dir}/DEBIAN"
    
    # 创建基础结构
    mkdir -p "${debian_dir}"
    generate_control_file "${base_dir}" "${project_name}" "${project_type}"
    
    # 创建postinst脚本
    cp "${TEMPLATES_DIR}/postinst.tpl" "${debian_dir}/postinst"
    chmod 755 "${debian_dir}/postinst"
    sed -i "s/%NAME%/${project_name}/g" "${debian_dir}/postinst"
    
    # 创建postrm脚本
    cp "${TEMPLATES_DIR}/postrm.tpl" "${debian_dir}/postrm"
    chmod 755 "${debian_dir}/postrm"
    sed -i "s/%NAME%/${project_name}/g" "${debian_dir}/postrm"
    
    # 根据类型创建特定目录
    case ${project_type} in
        # 无根类型
        "rootless-app")
            mkdir -p "${base_dir}/var/jb/Applications/${project_name}.app"
            touch "${base_dir}/var/jb/Applications/${project_name}.app/Info.plist"
            log "INFO" "${CYAN}创建无根应用目录: ${base_dir}/var/jb/Applications/${project_name}.app${NC}"
            ;;
        "rootless-tweak")
            mkdir -p "${base_dir}/var/jb/Library/MobileSubstrate/DynamicLibraries"
            mkdir -p "${base_dir}/var/jb/Library/PreferenceLoader/Preferences"
            mkdir -p "${base_dir}/var/jb/System/Library/PreferenceBundles"
            touch "${base_dir}/var/jb/Library/MobileSubstrate/DynamicLibraries/${project_name}.dylib"
            create_plist_filter "${base_dir}" "${project_name}" "${project_type}"
            log "INFO" "${CYAN}创建无根插件目录: ${base_dir}/var/jb/Library/MobileSubstrate${NC}"
            ;;
        "rootless-theme")
            mkdir -p "${base_dir}/var/jb/Library/Themes/${project_name}.theme"
            mkdir -p "${base_dir}/var/jb/Library/Themes/${project_name}.theme/IconBundles"
            log "INFO" "${CYAN}创建无根主题目录: ${base_dir}/var/jb/Library/Themes${NC}"
            ;;
        "rootless-tool")
            mkdir -p "${base_dir}/var/jb/usr/bin"
            touch "${base_dir}/var/jb/usr/bin/${project_name}"
            chmod +x "${base_dir}/var/jb/usr/bin/${project_name}"
            log "INFO" "${CYAN}创建无根工具目录: ${base_dir}/var/jb/usr/bin${NC}"
            ;;
        "rootless-prefs")
            mkdir -p "${base_dir}/var/jb/Library/PreferenceLoader/Preferences"
            mkdir -p "${base_dir}/var/jb/Library/PreferenceBundles/${project_name}.bundle"
            touch "${base_dir}/var/jb/Library/PreferenceLoader/Preferences/${project_name}.plist"
            log "INFO" "${CYAN}创建无根偏好设置目录: ${base_dir}/var/jb/Library/PreferenceBundles${NC}"
            ;;
        "rootless-font")
            mkdir -p "${base_dir}/var/jb/Library/Fonts/${project_name}"
            log "INFO" "${CYAN}创建无根字体目录: ${base_dir}/var/jb/Library/Fonts${NC}"
            ;;
        "rootless-daemon")
            mkdir -p "${base_dir}/var/jb/Library/LaunchDaemons"
            mkdir -p "${base_dir}/var/jb/usr/bin"
            touch "${base_dir}/var/jb/usr/bin/${project_name}"
            chmod +x "${base_dir}/var/jb/usr/bin/${project_name}"
            sed -e "s/%NAME%/${project_name}/g" \
                "${TEMPLATES_DIR}/launchd.tpl" > "${base_dir}/var/jb/Library/LaunchDaemons/${project_name}.plist"
            log "INFO" "${CYAN}创建无根守护进程: ${base_dir}/var/jb/Library/LaunchDaemons${NC}"
            ;;
        "rootless-emoji")
            mkdir -p "${base_dir}/var/jb/Library/Fonts/${project_name}"
            log "INFO" "${CYAN}创建无根Emoji字体目录: ${base_dir}/var/jb/Library/Fonts${NC}"
            ;;
        "rootless-statusbar")
            mkdir -p "${base_dir}/var/jb/Library/MobileSubstrate/DynamicLibraries"
            mkdir -p "${base_dir}/var/jb/Library/StatusBar"
            touch "${base_dir}/var/jb/Library/MobileSubstrate/DynamicLibraries/${project_name}.dylib"
            create_plist_filter "${base_dir}" "${project_name}" "${project_type}"
            log "INFO" "${CYAN}创建无根状态栏主题: ${base_dir}/var/jb/Library/StatusBar${NC}"
            ;;
        "rootless-keyboard")
            mkdir -p "${base_dir}/var/jb/Library/MobileSubstrate/DynamicLibraries"
            mkdir -p "${base_dir}/var/jb/Library/Keyboard"
            touch "${base_dir}/var/jb/Library/MobileSubstrate/DynamicLibraries/${project_name}.dylib"
            create_plist_filter "${base_dir}" "${project_name}" "${project_type}"
            log "INFO" "${CYAN}创建无根键盘主题: ${base_dir}/var/jb/Library/Keyboard${NC}"
            ;;
        "rootless-sound")
            mkdir -p "${base_dir}/var/jb/Library/Sounds"
            log "INFO" "${CYAN}创建无根音效目录: ${base_dir}/var/jb/Library/Sounds${NC}"
            ;;
        "rootless-wallpaper")
            mkdir -p "${base_dir}/var/jb/Library/Wallpaper"
            log "INFO" "${CYAN}创建无根壁纸目录: ${base_dir}/var/jb/Library/Wallpaper${NC}"
            ;;
        "rootless-language")
            mkdir -p "${base_dir}/var/jb/Library/Keyboard/Localizations"
            log "INFO" "${CYAN}创建无根语言包目录: ${base_dir}/var/jb/Library/Keyboard/Localizations${NC}"
            ;;
        "rootless-livewallpaper")
            mkdir -p "${base_dir}/var/jb/Library/LiveWallpapers"
            log "INFO" "${CYAN}创建无根动态壁纸目录: ${base_dir}/var/jb/Library/LiveWallpapers${NC}"
            ;;
        "rootless-ccmodule")
            mkdir -p "${base_dir}/var/jb/Library/ControlCenter/Bundles"
            mkdir -p "${base_dir}/var/jb/Library/MobileSubstrate/DynamicLibraries"
            touch "${base_dir}/var/jb/Library/MobileSubstrate/DynamicLibraries/${project_name}.dylib"
            create_plist_filter "${base_dir}" "${project_name}" "${project_type}"
            log "INFO" "${CYAN}创建无根控制中心模块: ${base_dir}/var/jb/Library/ControlCenter/Bundles${NC}"
            ;;
        "rootless-today")
            mkdir -p "${base_dir}/var/jb/Library/TodayView"
            mkdir -p "${base_dir}/var/jb/Library/MobileSubstrate/DynamicLibraries"
            touch "${base_dir}/var/jb/Library/MobileSubstrate/DynamicLibraries/${project_name}.dylib"
            create_plist_filter "${base_dir}" "${project_name}" "${project_type}"
            log "INFO" "${CYAN}创建无根通知中心组件: ${base_dir}/var/jb/Library/TodayView${NC}"
            ;;
        "pure-rootless")
            log "INFO" "${PURPLE}创建纯无根DEB基础结构${NC}"
            ;;
        
        # 有根类型
        "rooted-app")
            mkdir -p "${base_dir}/Applications/${project_name}.app"
            touch "${base_dir}/Applications/${project_name}.app/Info.plist"
            log "INFO" "${YELLOW}创建有根应用目录: ${base_dir}/Applications/${project_name}.app${NC}"
            ;;
        "rooted-tweak")
            mkdir -p "${base_dir}/Library/MobileSubstrate/DynamicLibraries"
            mkdir -p "${base_dir}/Library/PreferenceLoader/Preferences"
            mkdir -p "${base_dir}/System/Library/PreferenceBundles"
            touch "${base_dir}/Library/MobileSubstrate/DynamicLibraries/${project_name}.dylib"
            create_plist_filter "${base_dir}" "${project_name}" "${project_type}"
            log "INFO" "${YELLOW}创建有根插件目录: ${base_dir}/Library/MobileSubstrate${NC}"
            ;;
        "rooted-theme")
            mkdir -p "${base_dir}/Library/Themes/${project_name}.theme"
            mkdir -p "${base_dir}/Library/Themes/${project_name}.theme/IconBundles"
            log "INFO" "${YELLOW}创建有根主题目录: ${base_dir}/Library/Themes${NC}"
            ;;
        "rooted-tool")
            mkdir -p "${base_dir}/usr/bin"
            touch "${base_dir}/usr/bin/${project_name}"
            chmod +x "${base_dir}/usr/bin/${project_name}"
            log "INFO" "${YELLOW}创建有根工具目录: ${base_dir}/usr/bin${NC}"
            ;;
        "rooted-prefs")
            mkdir -p "${base_dir}/Library/PreferenceLoader/Preferences"
            mkdir -p "${base_dir}/Library/PreferenceBundles/${project_name}.bundle"
            touch "${base_dir}/Library/PreferenceLoader/Preferences/${project_name}.plist"
            log "INFO" "${YELLOW}创建有根偏好设置目录: ${base_dir}/Library/PreferenceBundles${NC}"
            ;;
        "rooted-font")
            mkdir -p "${base_dir}/Library/Fonts/${project_name}"
            log "INFO" "${YELLOW}创建有根字体目录: ${base_dir}/Library/Fonts${NC}"
            ;;
        "rooted-daemon")
            mkdir -p "${base_dir}/Library/LaunchDaemons"
            mkdir -p "${base_dir}/usr/bin"
            touch "${base_dir}/usr/bin/${project_name}"
            chmod +x "${base_dir}/usr/bin/${project_name}"
            sed -e "s/%NAME%/${project_name}/g" \
                "${TEMPLATES_DIR}/launchd.tpl" > "${base_dir}/Library/LaunchDaemons/${project_name}.plist"
            log "INFO" "${YELLOW}创建有根守护进程: ${base_dir}/Library/LaunchDaemons${NC}"
            ;;
        "rooted-emoji")
            mkdir -p "${base_dir}/Library/Fonts/${project_name}"
            log "INFO" "${YELLOW}创建有根Emoji字体目录: ${base_dir}/Library/Fonts${NC}"
            ;;
        "rooted-statusbar")
            mkdir -p "${base_dir}/Library/MobileSubstrate/DynamicLibraries"
            mkdir -p "${base_dir}/Library/StatusBar"
            touch "${base_dir}/Library/MobileSubstrate/DynamicLibraries/${project_name}.dylib"
            create_plist_filter "${base_dir}" "${project_name}" "${project_type}"
            log "INFO" "${YELLOW}创建有根状态栏主题: ${base_dir}/Library/StatusBar${NC}"
            ;;
        "rooted-keyboard")
            mkdir -p "${base_dir}/Library/MobileSubstrate/DynamicLibraries"
            mkdir -p "${base_dir}/Library/Keyboard"
            touch "${base_dir}/Library/MobileSubstrate/DynamicLibraries/${project_name}.dylib"
            create_plist_filter "${base_dir}" "${project_name}" "${project_type}"
            log "INFO" "${YELLOW}创建有根键盘主题: ${base_dir}/Library/Keyboard${NC}"
            ;;
        "rooted-sound")
            mkdir -p "${base_dir}/Library/Sounds"
            log "INFO" "${YELLOW}创建有根音效目录: ${base_dir}/Library/Sounds${NC}"
            ;;
        "rooted-wallpaper")
            mkdir -p "${base_dir}/Library/Wallpaper"
            log "INFO" "${YELLOW}创建有根壁纸目录: ${base_dir}/Library/Wallpaper${NC}"
            ;;
        "rooted-language")
            mkdir -p "${base_dir}/Library/Keyboard/Localizations"
            log "INFO" "${YELLOW}创建有根语言包目录: ${base_dir}/Library/Keyboard/Localizations${NC}"
            ;;
        "rooted-livewallpaper")
            mkdir -p "${base_dir}/Library/LiveWallpapers"
            log "INFO" "${YELLOW}创建有根动态壁纸目录: ${base_dir}/Library/LiveWallpapers${NC}"
            ;;
        "rooted-ccmodule")
            mkdir -p "${base_dir}/Library/ControlCenter/Bundles"
            mkdir -p "${base_dir}/Library/MobileSubstrate/DynamicLibraries"
            touch "${base_dir}/Library/MobileSubstrate/DynamicLibraries/${project_name}.dylib"
            create_plist_filter "${base_dir}" "${project_name}" "${project_type}"
            log "INFO" "${YELLOW}创建有根控制中心模块: ${base_dir}/Library/ControlCenter/Bundles${NC}"
            ;;
        "rooted-today")
            mkdir -p "${base_dir}/Library/TodayView"
            mkdir -p "${base_dir}/Library/MobileSubstrate/DynamicLibraries"
            touch "${base_dir}/Library/MobileSubstrate/DynamicLibraries/${project_name}.dylib"
            create_plist_filter "${base_dir}" "${project_name}" "${project_type}"
            log "INFO" "${YELLOW}创建有根通知中心组件: ${base_dir}/Library/TodayView${NC}"
            ;;
        "pure-rooted")
            log "INFO" "${PURPLE}创建纯有根DEB基础结构${NC}"
            ;;
    esac

    log "INFO" "${GREEN}✅ 项目创建完成于: ${base_dir}${NC}"
}
