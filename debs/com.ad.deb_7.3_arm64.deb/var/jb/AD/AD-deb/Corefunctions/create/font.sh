#!/bin/bash

create_font_project() {
    local project_type="$1"
    local project_name=""
    
    # 验证项目ID格式
    while true; do
        read -p "请输入字体包ID (例如 com.公司.字体名): " project_name
        if validate_project_name "${project_name}"; then
            break
        fi
    done

    local base_dir="${PROJECTS_DIR}/${project_type}_${project_name}"
    local debian_dir="${base_dir}/DEBIAN"
    local font_dir=""
    
    # 创建基础结构
    mkdir -p "${debian_dir}"
    generate_control_file "${base_dir}" "${project_name}" "${project_type}"
    
    # 创建字体安装脚本
    cp "${TEMPLATES_DIR}/font_postinst.tpl" "${debian_dir}/postinst"
    chmod 755 "${debian_dir}/postinst"
    sed -i "s/%NAME%/${project_name}/g" "${debian_dir}/postinst"
    
    # 创建卸载脚本
    cp "${TEMPLATES_DIR}/postrm.tpl" "${debian_dir}/postrm"
    chmod 755 "${debian_dir}/postrm"
    sed -i "s/%NAME%/${project_name}/g" "${debian_dir}/postrm"
    
    # 根据类型创建字体目录
    if [[ "${project_type}" == rootless-* ]]; then
        font_dir="${base_dir}/var/jb/Library/Fonts/${project_name}"
    else
        font_dir="${base_dir}/Library/Fonts/${project_name}"
    fi
    
    mkdir -p "${font_dir}"
    log "INFO" "${GREEN}✅ 字体目录已创建: ${font_dir}${NC}"
    
    # 提示添加字体文件
    echo -e "${CYAN}请将字体文件(.ttf/.otf)放入以下目录:"
    echo -e "${font_dir}"
    echo -e "完成后可以执行打包操作${NC}"
    
    log "INFO" "${GREEN}✅ 字体项目创建完成于: ${base_dir}${NC}"
}
