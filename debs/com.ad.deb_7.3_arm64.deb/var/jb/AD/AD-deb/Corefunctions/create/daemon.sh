#!/bin/bash

create_daemon_project() {
    local project_type="$1"
    local project_name=""
    
    # 验证项目ID格式
    while true; do
        read -p "请输入守护进程ID (例如 com.公司.daemon): " project_name
        if validate_project_name "${project_name}"; then
            break
        fi
    done

    local base_dir="${PROJECTS_DIR}/${project_type}_${project_name}"
    local debian_dir="${base_dir}/DEBIAN"
    local daemon_dir=""
    
    # 创建基础结构
    mkdir -p "${debian_dir}"
    generate_control_file "${base_dir}" "${project_name}" "${project_type}"
    
    # 创建postinst脚本
    cp "${TEMPLATES_DIR}/postinst.tpl" "${debian_dir}/postinst"
    chmod 755 "${debian_dir}/postinst"
    sed -i "s/%NAME%/${project_name}/g" "${debian_dir}/postinst"
    
    # 创建postrm脚本
    cp "${TEMPLATES_DIR}/postrm.tpl" "${debian_dir}/postrm"
    chmod 755 "${debian_dir}/postrm"
    sed -i "s/%NAME%/${project_name}/g" "${debian_dir}/postrm"
    
    # 根据类型创建守护进程目录
    if [[ "${project_type}" == rootless-* ]]; then
        daemon_dir="${base_dir}/var/jb/Library/LaunchDaemons"
    else
        daemon_dir="${base_dir}/Library/LaunchDaemons"
    fi
    
    mkdir -p "${daemon_dir}"
    
    # 创建守护进程plist文件
    sed -e "s/%NAME%/${project_name}/g" \
        "${TEMPLATES_DIR}/launchd.tpl" > "${daemon_dir}/${project_name}.plist"
    
    log "INFO" "${GREEN}✅ 守护进程plist文件已创建: ${daemon_dir}/${project_name}.plist${NC}"
    
    # 创建二进制文件
    if [[ "${project_type}" == rootless-* ]]; then
        mkdir -p "${base_dir}/var/jb/usr/bin"
        touch "${base_dir}/var/jb/usr/bin/${project_name}"
        chmod +x "${base_dir}/var/jb/usr/bin/${project_name}"
        log "INFO" "${GREEN}✅ 守护进程二进制文件已创建: ${base_dir}/var/jb/usr/bin/${project_name}${NC}"
    else
        mkdir -p "${base_dir}/usr/bin"
        touch "${base_dir}/usr/bin/${project_name}"
        chmod +x "${base_dir}/usr/bin/${project_name}"
        log "INFO" "${GREEN}✅ 守护进程二进制文件已创建: ${base_dir}/usr/bin/${project_name}${NC}"
    fi
    
    log "INFO" "${GREEN}✅ 守护进程项目创建完成于: ${base_dir}${NC}"
}
