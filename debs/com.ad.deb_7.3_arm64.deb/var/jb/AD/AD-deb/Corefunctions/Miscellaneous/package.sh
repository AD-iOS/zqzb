#!/bin/bash

build_deb_package() {
    echo -e "${CYAN}"
    echo "可用的项目目录:"
    echo "---------------------------------------------"
    ls -1 "${PROJECTS_DIR}" | grep -E '^(rootless|rooted)' | nl
    echo "---------------------------------------------"
    echo -e "${NC}"
    
    read -p "输入要打包的项目编号 (或输入'all'打包所有): " project_num
    
    if [[ "${project_num}" == "all" ]]; then
        # 批量打包所有项目
        local projects=($(ls -1 "${PROJECTS_DIR}" | grep -E '^(rootless|rooted)'))
        local success_count=0
        local fail_count=0
        
        for project in "${projects[@]}"; do
            local project_dir="${PROJECTS_DIR}/${project}"
            local output_deb="${project}.deb"
            
            dpkg-deb -b "${project_dir}" "${output_deb}" >/dev/null 2>&1
            
            if [ $? -eq 0 ]; then
                log "INFO" "${GREEN}✅ ${project} 打包成功: ${output_deb}${NC}"
                ((success_count++))
            else
                log "ERROR" "${RED}❌ ${project} 打包失败${NC}"
                ((fail_count++))
            fi
        done
        
        log "INFO" "${BLUE}批量打包完成: 成功 ${success_count}个, 失败 ${fail_count}个${NC}"
    else
        # 单个项目打包
        local projects=($(ls -1 "${PROJECTS_DIR}" | grep -E '^(rootless|rooted)'))
        local selected_project="${projects[$((project_num-1))]}"
        
        if [ -z "${selected_project}" ]; then
            log "ERROR" "${RED}❌ 无效的项目编号${NC}"
            return 1
        fi
        
        local project_dir="${PROJECTS_DIR}/${selected_project}"
        local output_deb="${selected_project}.deb"
        
        dpkg-deb -b "${project_dir}" "${output_deb}" >/dev/null 2>&1
        
        if [ $? -eq 0 ]; then
            log "INFO" "${GREEN}✅ DEB包构建成功: ${output_deb}${NC}"
            log "INFO" "${BLUE}文件大小: $(du -h "${output_deb}" | cut -f1)${NC}"
            
            # 检查依赖是否满足
            check_dependencies "${project_dir}"
        else
            log "ERROR" "${RED}❌ DEB包构建失败${NC}"
        fi
    fi
}
