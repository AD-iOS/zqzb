#!/bin/bash

manage_projects() {
    while true; do
        clear
        echo -e "${CYAN}"
        echo "项目管理"
        echo "---------------------------------------------"
        echo "1. 列出所有项目"
        echo "2. 打包DEB (单个/批量)"
        echo "3. 删除项目"
        echo "4. 编辑项目文件"
        echo "5. 检查项目结构"
        echo "6. 批量操作"
        echo "7. 返回主菜单"
        echo "---------------------------------------------"
        echo -e "${NC}"
        
        read -p "请输入选项: " choice
        case $choice in
            1)
                echo -e "${CYAN}"
                echo "现有项目列表:"
                echo "---------------------------------------------"
                ls -l "${PROJECTS_DIR}"
                echo "---------------------------------------------"
                echo -e "${NC}"
                read -n 1 -s -r -p "按任意键继续..."
                ;;
            2) build_deb_package;;
            3)
                echo -e "${CYAN}"
                echo "可删除的项目:"
                echo "---------------------------------------------"
                ls -1 "${PROJECTS_DIR}" | grep -E '^(rootless|rooted)' | nl
                echo "---------------------------------------------"
                echo -e "${NC}"
                read -p "输入要删除的项目编号: " del_num
                local del_projects=($(ls -1 "${PROJECTS_DIR}" | grep -E '^(rootless|rooted)'))
                local del_project="${del_projects[$((del_num-1))]}"
                if [ -n "${del_project}" ]; then
                    rm -rf "${PROJECTS_DIR}/${del_project}"
                    log "INFO" "${GREEN}✅ 项目已删除: ${del_project}${NC}"
                else
                    log "ERROR" "${RED}❌ 无效的项目编号${NC}"
                fi
                ;;
            4)
                echo -e "${CYAN}"
                echo "可编辑的项目:"
                echo "---------------------------------------------"
                ls -1 "${PROJECTS_DIR}" | grep -E '^(rootless|rooted)' | nl
                echo "---------------------------------------------"
                echo -e "${NC}"
                read -p "输入要编辑的项目编号: " edit_num
                local edit_projects=($(ls -1 "${PROJECTS_DIR}" | grep -E '^(rootless|rooted)'))
                local edit_project="${edit_projects[$((edit_num-1))]}"
                if [ -n "${edit_project}" ]; then
                    edit_project_files "${PROJECTS_DIR}/${edit_project}"
                else
                    log "ERROR" "${RED}❌ 无效的项目编号${NC}"
                fi
                ;;
            5)
                echo -e "${CYAN}"
                echo "项目结构检查:"
                echo "---------------------------------------------"
                ls -1 "${PROJECTS_DIR}" | grep -E '^(rootless|rooted)' | nl
                echo "---------------------------------------------"
                echo -e "${NC}"
                read -p "输入要检查的项目编号: " check_num
                local check_projects=($(ls -1 "${PROJECTS_DIR}" | grep -E '^(rootless|rooted)'))
                local check_project="${check_projects[$((check_num-1))]}"
                if [ -n "${check_project}" ]; then
                    check_project_structure "${PROJECTS_DIR}/${check_project}"
                else
                    log "ERROR" "${RED}❌ 无效的项目编号${NC}"
                fi
                ;;
            6) batch_operations ;;
            7) return 0 ;;
            *) log "ERROR" "${RED}❌ 无效选项${NC}";;
        esac
    done
}
