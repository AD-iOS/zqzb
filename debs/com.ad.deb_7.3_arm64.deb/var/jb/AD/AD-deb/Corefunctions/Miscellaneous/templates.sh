#!/bin/bash

init_templates() {
    mkdir -p "${TEMPLATES_DIR}"
    
    # 控制文件模板
    cat > "${TEMPLATES_DIR}/control.tpl" <<'EOF'
Package: %PACKAGE%
Name: %NAME%
Version: 1.0
Architecture: iphoneos-arm
Description: %DESCRIPTION%
Maintainer: %MAINTAINER%
Author: %AUTHOR%
Section: %SECTION%
Depends: %DEPENDS%
Priority: optional
Homepage: %HOMEPAGE%
EOF

    # 预加载脚本模板
    cat > "${TEMPLATES_DIR}/postinst.tpl" <<'EOF'
#!/bin/bash
# Post-installation script for %NAME%

echo "Running post-installation script for %NAME%"

# 加载动态库
if [ -e /Library/MobileSubstrate/DynamicLibraries/%NAME%.dylib ]; then
    /usr/bin/killall -9 SpringBoard
elif [ -e /var/jb/Library/MobileSubstrate/DynamicLibraries/%NAME%.dylib ]; then
    /var/jb/usr/bin/killall -9 SpringBoard
fi

# 设置权限
find /var/jb/Library/PreferenceLoader/Preferences/%NAME% /var/jb/Library/MobileSubstrate/DynamicLibraries/%NAME%.* -exec chmod 755 {} \;

# 刷新字体缓存
if [ -d "/Library/Fonts" ] || [ -d "/var/jb/Library/Fonts" ]; then
    uicache --all
    killall -9 backboardd
fi

# 刷新图标缓存
if [ -d "/Library/Themes" ] || [ -d "/var/jb/Library/Themes" ]; then
    uicache --all --respring
fi

# 更新系统服务
if [ -f "/Library/LaunchDaemons/%NAME%.plist" ]; then
    launchctl unload "/Library/LaunchDaemons/%NAME%.plist" >/dev/null 2>&1
    launchctl load "/Library/LaunchDaemons/%NAME%.plist"
elif [ -f "/var/jb/Library/LaunchDaemons/%NAME%.plist" ]; then
    launchctl unload "/var/jb/Library/LaunchDaemons/%NAME%.plist" >/dev/null 2>&1
    launchctl load "/var/jb/Library/LaunchDaemons/%NAME%.plist"
fi

exit 0
EOF

    # 卸载脚本模板
    cat > "${TEMPLATES_DIR}/postrm.tpl" <<'EOF'
#!/bin/bash
# Post-removal script for %NAME%

echo "Running post-removal script for %NAME%"

# 清理残留文件
rm -rf /var/jb/Library/PreferenceLoader/Preferences/%NAME%
rm -rf /var/jb/Library/PreferenceBundles/%NAME%.bundle
rm -f /var/jb/Library/PreferenceLoader/Preferences/%NAME%.plist

# 清理字体缓存
if [ -d "/Library/Fonts/%NAME%" ] || [ -d "/var/jb/Library/Fonts/%NAME%" ]; then
    rm -rf "/Library/Fonts/%NAME%"
    rm -rf "/var/jb/Library/Fonts/%NAME%"
    uicache --all
    killall -9 backboardd
fi

# 停止系统服务
if [ -f "/Library/LaunchDaemons/%NAME%.plist" ]; then
    launchctl unload "/Library/LaunchDaemons/%NAME%.plist"
    rm -f "/Library/LaunchDaemons/%NAME%.plist"
elif [ -f "/var/jb/Library/LaunchDaemons/%NAME%.plist" ]; then
    launchctl unload "/var/jb/Library/LaunchDaemons/%NAME%.plist"
    rm -f "/var/jb/Library/LaunchDaemons/%NAME%.plist"
fi

exit 0
EOF

    # 过滤器模板
    cat > "${TEMPLATES_DIR}/filter.tpl" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Filter</key>
    <dict>
        <key>Bundles</key>
        <array>
            <string>com.apple.springboard</string>
        </array>
        <key>Executables</key>
        <array>
            <string>SpringBoard</string>
        </array>
    </dict>
</dict>
</plist>
EOF

    # 字体安装脚本模板
    cat > "${TEMPLATES_DIR}/font_postinst.tpl" <<'EOF'
#!/bin/bash
# 字体安装脚本

echo "Installing fonts..."

FONT_DIR=""
if [ -d "/var/jb/Library/Fonts" ]; then
    FONT_DIR="/var/jb/Library/Fonts/%NAME%"
else
    FONT_DIR="/Library/Fonts/%NAME%"
fi

mkdir -p "${FONT_DIR}"
chmod 755 "${FONT_DIR}"

# 刷新字体缓存
uicache --all
killall -9 backboardd

exit 0
EOF

    # 启动守护进程模板
    cat > "${TEMPLATES_DIR}/launchd.tpl" <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>%NAME%</string>
    <key>ProgramArguments</key>
    <array>
        <string>/usr/bin/%NAME%</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
    <key>StandardOutPath</key>
    <string>/var/log/%NAME%.log</string>
    <key>StandardErrorPath</key>
    <string>/var/log/%NAME%.err</string>
</dict>
</plist>
EOF

    # Emoji替换模板
    cat > "${TEMPLATES_DIR}/emoji_postinst.tpl" <<'EOF'
#!/bin/bash
# Emoji字体替换脚本

echo "Replacing emoji font..."

EMOJI_DIR="/System/Library/Fonts/Core"
if [ -d "/var/jb/System/Library/Fonts/Core" ]; then
    EMOJI_DIR="/var/jb/System/Library/Fonts/Core"
fi

# 备份原字体
if [ ! -f "${EMOJI_DIR}/AppleColorEmoji@2x.ttf.backup" ]; then
    cp "${EMOJI_DIR}/AppleColorEmoji@2x.ttf" "${EMOJI_DIR}/AppleColorEmoji@2x.ttf.backup"
fi

# 替换新字体
cp "/Library/Fonts/%NAME%/AppleColorEmoji@2x.ttf" "${EMOJI_DIR}/"

# 刷新缓存
uicache --all
killall -9 backboardd

exit 0
EOF

    log "INFO" "${GREEN}✅ 模板文件已初始化${NC}"
}
