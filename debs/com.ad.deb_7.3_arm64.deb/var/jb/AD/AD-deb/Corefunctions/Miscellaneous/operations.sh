#!/bin/bash

batch_operations() {
    while true; do
        clear
        echo -e "${CYAN}"
        echo "批量操作"
        echo "---------------------------------------------"
        echo "1. 批量打包所有项目"
        echo "2. 批量清理临时文件"
        echo "3. 批量更新版本号"
        echo "4. 批量添加字体"
        echo "5. 批量添加音效"
        echo "6. 返回主菜单"
        echo "---------------------------------------------"
        echo -e "${NC}"
        
        read -p "请输入选项: " choice
        case $choice in
            1)
                build_deb_package "all"
                read -n 1 -s -r -p "按任意键继续..."
                ;;
            2)
                find "${PROJECTS_DIR}" -type f \( -name "*.tmp" -o -name "*.bak" \) -delete
                log "INFO" "${GREEN}✅ 已清理所有临时文件${NC}"
                read -n 1 -s -r -p "按任意键继续..."
                ;;
            3)
                for version_file in "${CACHE_DIR}"/*.version; do
                    if [ -f "${version_file}" ]; then
                        local pkg_name=$(basename "${version_file}" .version)
                        local new_version=$(awk -F. '{$NF+=1; OFS="."; print $0}' "${version_file}")
                        echo "${new_version}" > "${version_file}"
                        log "INFO" "${GREEN}✅ ${pkg_name} 版本号更新为 ${new_version}${NC}"
                    fi
                done
                read -n 1 -s -r -p "按任意键继续..."
                ;;
            4)
                read -p "输入字体文件路径(支持通配符如 *.ttf): " font_path
                read -p "输入目标项目编号: " target_num
                
                local projects=($(ls -1 "${PROJECTS_DIR}" | grep -E '^(rootless|rooted)'))
                local target_project="${projects[$((target_num-1))]}"
                
                if [ -z "${target_project}" ]; then
                    log "ERROR" "${RED}❌ 无效的项目编号${NC}"
                    continue
                fi
                
                local font_dir=""
                if [[ "${target_project}" == rootless-* ]]; then
                    font_dir="${PROJECTS_DIR}/${target_project}/var/jb/Library/Fonts"
                else
                    font_dir="${PROJECTS_DIR}/${target_project}/Library/Fonts"
                fi
                
                if [ ! -d "${font_dir}" ]; then
                    log "ERROR" "${RED}❌ 目标项目不是字体项目${NC}"
                    continue
                fi
                
                # 复制字体文件
                for font in ${font_path}; do
                    if [ -f "${font}" ]; then
                        cp "${font}" "${font_dir}/"
                        log "INFO" "${GREEN}✅ 已添加字体: $(basename "${font}")${NC}"
                    fi
                done
                
                read -n 1 -s -r -p "按任意键继续..."
                ;;
            5)
                read -p "输入音效文件路径(支持通配符如 *.caf): " sound_path
                read -p "输入目标项目编号: " target_num
                
                local projects=($(ls -1 "${PROJECTS_DIR}" | grep -E '^(rootless|rooted)'))
                local target_project="${projects[$((target_num-1))]}"
                
                if [ -z "${target_project}" ]; then
                    log "ERROR" "${RED}❌ 无效的项目编号${NC}"
                    continue
                fi
                
                local sound_dir=""
                if [[ "${target_project}" == rootless-* ]]; then
                    sound_dir="${PROJECTS_DIR}/${target_project}/var/jb/Library/Sounds"
                else
                    sound_dir="${PROJECTS_DIR}/${target_project}/Library/Sounds"
                fi
                
                if [ ! -d "${sound_dir}" ]; then
                    log "ERROR" "${RED}❌ 目标项目不是音效项目${NC}"
                    continue
                fi
                
                # 复制音效文件
                for sound in ${sound_path}; do
                    if [ -f "${sound}" ]; then
                        cp "${sound}" "${sound_dir}/"
                        log "INFO" "${GREEN}✅ 已添加音效: $(basename "${sound}")${NC}"
                    fi
                done
                
                read -n 1 -s -r -p "按任意键继续..."
                ;;
            6) return 0 ;;
            *) log "ERROR" "${RED}❌ 无效选项${NC}";;
        esac
    done
}
