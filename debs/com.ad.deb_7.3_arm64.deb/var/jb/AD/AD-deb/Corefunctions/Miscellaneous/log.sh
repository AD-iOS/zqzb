#!/bin/bash

log() {
    local level="$1"
    local message="$2"
    local timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    local color=""
    local clean_msg=$(echo -e "$message" | sed -r "s/\x1B\[([0-9]{1,3}(;[0-9]{1,2})?)?[mGK]//g")
    
    case $level in
        "ERROR") color="${RED}❌ ";;
        "WARN") color="${YELLOW}⚠️ ";;
        "INFO") color="${GREEN}ℹ️ ";;
        "DEBUG") color="${CYAN}🐛 ";;
        *) color="${BLUE}";;
    esac
    
    echo -e "${color}${message}${NC}"
    echo "${timestamp} [${level}] ${clean_msg}" >> "${MAIN_LOG}"
    
    [[ $level == "ERROR" ]] && echo "${timestamp} ${clean_msg}" >> "${ERROR_LOG}"
    [[ $level == "DEBUG" ]] && echo "${timestamp} ${clean_msg}" >> "${DEBUG_LOG}"
}
