#!/bin/bash

validate_project_name() {
    local name="$1"
    if [[ ! "${name}" =~ ^[a-zA-Z][a-zA-Z0-9.-]+$ ]]; then
        log "ERROR" "${RED}❌ 名称必须以字母开头，只能包含英文、数字、点和横线${NC}"
        return 1
    fi
    return 0
}

generate_control_file() {
    local project_dir="$1"
    local project_name="$2"
    local project_type="$3"
    
    # 获取用户输入
    read -p "输入插件显示名称: " display_name
    read -p "输入插件描述: " description
    read -p "输入维护者信息 (姓名 <邮箱>): " maintainer
    read -p "输入作者信息 [默认同维护者]: " author
    author=${author:-$maintainer}
    read -p "输入主页URL [可选]: " homepage
    
    # 检查版本号缓存
    local version_cache="${CACHE_DIR}/${project_name}.version"
    local version="1.0"
    if [ -f "${version_cache}" ]; then
        version=$(awk -F. '{$NF+=1; OFS="."; print $0}' "${version_cache}")
    fi
    echo "${version}" > "${version_cache}"
    
    # 设置默认的Section和Depends
    local section="Tweaks"
    local depends="firmware (>= 13.0)"
    local architecture="iphoneos-arm64"
    
    case ${project_type} in
        *-tweak*) 
            section="Tweaks"
            depends="$depends, mobilesubstrate"
            ;;
        *-theme*) section="Themes" ;;
        *-app*) section="Applications" ;;
        *-tool*) section="Utilities" ;;
        *-font*) section="Fonts" ;;
        *-daemon*) section="System" ;;
        *-emoji*) section="Fonts" ;;
        *-statusbar*) section="Tweaks" ;;
        *-keyboard*) section="Tweaks" ;;
        *-sound*) section="Multimedia" ;;
        *-wallpaper*) section="Wallpaper" ;;
        *-language*) section="Localization" ;;
        *-livewallpaper*) section="Wallpaper" ;;
        *-ccmodule*) section="Tweaks" ;;
        *-today*) section="Tweaks" ;;
    esac
    
    # 使用模板生成control文件
    sed -e "s/%PACKAGE%/${project_name}/g" \
        -e "s/%NAME%/${display_name}/g" \
        -e "s/%DESCRIPTION%/${description}/g" \
        -e "s/%MAINTAINER%/${maintainer}/g" \
        -e "s/%AUTHOR%/${author}/g" \
        -e "s/%SECTION%/${section}/g" \
        -e "s/%DEPENDS%/${depends}/g" \
        -e "s/%HOMEPAGE%/${homepage}/g" \
        -e "s/Version: 1.0/Version: ${version}/g" \
        "${TEMPLATES_DIR}/control.tpl" > "${project_dir}/DEBIAN/control"
    
    log "INFO" "${GREEN}✅ control文件已生成 (版本 ${version})${NC}"
}
