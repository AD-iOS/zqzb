#!/bin/bash

edit_project_files() {
    local project_dir="$1"
    
    while true; do
        clear
        echo -e "${CYAN}"
        echo "编辑项目: $(basename "${project_dir}")"
        echo "---------------------------------------------"
        echo "1. 编辑control文件"
        echo "2. 编辑postinst脚本"
        echo "3. 编辑postrm脚本"
        echo "4. 编辑plist过滤器"
        echo "5. 编辑launchd plist (守护进程)"
        echo "6. 添加新文件"
        echo "7. 返回项目管理"
        echo "---------------------------------------------"
        echo -e "${NC}"
        
        # 查找plist文件
        local plist_file=$(find "${project_dir}" -name "*.plist" | head -n 1)
        local launchd_file=$(find "${project_dir}" -path "*/LaunchDaemons/*.plist" | head -n 1)
        
        read -p "请输入选项: " choice
        case $choice in
            1)
                nano "${project_dir}/DEBIAN/control"
                log "INFO" "${GREEN}✅ control文件已更新${NC}"
                ;;
            2)
                nano "${project_dir}/DEBIAN/postinst"
                chmod 755 "${project_dir}/DEBIAN/postinst"
                log "INFO" "${GREEN}✅ postinst脚本已更新${NC}"
                ;;
            3)
                nano "${project_dir}/DEBIAN/postrm"
                chmod 755 "${project_dir}/DEBIAN/postrm"
                log "INFO" "${GREEN}✅ postrm脚本已更新${NC}"
                ;;
            4)
                if [ -n "${plist_file}" ]; then
                    edit_plist_file "${plist_file}"
                else
                    log "WARN" "${YELLOW}⚠️ 该项目没有plist过滤器${NC}"
                fi
                ;;
            5)
                if [ -n "${launchd_file}" ]; then
                    edit_plist_file "${launchd_file}"
                else
                    log "WARN" "${YELLOW}⚠️ 该项目没有launchd plist文件${NC}"
                fi
                ;;
            6)
                read -p "输入要添加的文件路径 (相对于项目根目录): " file_path
                mkdir -p "${project_dir}/$(dirname "${file_path}")"
                touch "${project_dir}/${file_path}"
                log "INFO" "${GREEN}✅ 已添加文件: ${file_path}${NC}"
                ;;
            7) return 0 ;;
            *) log "ERROR" "${RED}❌ 无效选项${NC}";;
        esac
        
        read -n 1 -s -r -p "按任意键继续..."
    done
}
