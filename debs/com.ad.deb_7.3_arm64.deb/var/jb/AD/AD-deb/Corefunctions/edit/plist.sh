#!/bin/bash

edit_plist_file() {
    local plist_path="$1"
    
    # 检查是否安装了plutil
    if ! command -v plutil &> /dev/null; then
        log "WARN" "${YELLOW}⚠️ plutil工具未安装，无法直接编辑plist文件${NC}"
        return
    fi
    
    echo -e "${CYAN}"
    echo "当前plist内容:"
    echo "---------------------------------------------"
    plutil -p "${plist_path}" || cat "${plist_path}"
    echo "---------------------------------------------"
    echo -e "${NC}"
    
    echo -e "${GREEN}可用的编辑操作:"
    echo "1. 添加/修改键值"
    echo "2. 删除键"
    echo "3. 添加数组元素"
    echo "4. 退出编辑器"
    echo -e "${NC}"
    
    while true; do
        read -p "选择操作 (1-4): " action
        case $action in
            1)
                read -p "输入键路径 (如 Filter.Bundles): " key_path
                read -p "输入值 (字符串直接输入，数组用逗号分隔): " value
                
                # 处理数组值
                if [[ "$value" == *,* ]]; then
                    IFS=',' read -ra values <<< "$value"
                    plutil -replace "$key_path" -json "["$(printf '"%s",' "${values[@]}" | sed 's/,$//')"]" "$plist_path"
                else
                    plutil -replace "$key_path" -string "$value" "$plist_path"
                fi
                ;;
            2)
                read -p "输入要删除的键路径: " key_path
                plutil -remove "$key_path" "$plist_path"
                ;;
            3)
                read -p "输入数组键路径: " key_path
                read -p "输入要添加的值: " value
                plutil -insert "$key_path" -string "$value" "$plist_path"
                ;;
            4) break ;;
            *) echo "无效选择" ;;
        esac
        
        echo -e "${CYAN}"
        echo "更新后的plist内容:"
        echo "---------------------------------------------"
        plutil -p "${plist_path}"
        echo "---------------------------------------------"
        echo -e "${NC}"
    done
}
