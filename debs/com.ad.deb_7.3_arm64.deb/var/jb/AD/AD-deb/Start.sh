#!/bin/bash

# ========================
# 越狱DEB工具 v7.0 - 修复版
# ========================

# 确保工作目录存在
mkdir -p /var/jb/AD/AD-deb/DEB_Projects
mkdir -p /var/jb/AD/AD-deb/deb_config

# 如果符号链接不存在则创建（双重保险）
[ ! -L "/var/mobile/Documents/AD-deb/DEB_Projects" ] && \
    ln -sf /var/jb/AD/AD-deb/DEB_Projects /var/mobile/Documents/AD-deb/DEB_Projects

[ ! -L "/var/mobile/Documents/AD-deb/deb_config" ] && \
    ln -sf /var/jb/AD/AD-deb/deb_config /var/mobile/Documents/AD-deb/deb_config


# 初始化全局变量
SCRIPT_DIR=""
CORE_FUNCTIONS_DIR=""
CONFIG_DIR=""
LOG_DIR=""
TEMPLATES_DIR=""
PROJECTS_DIR=""

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

# 安全获取脚本目录（兼容各种调用方式）
get_script_dir() {
    SOURCE="${BASH_SOURCE[0]}"
    while [ -h "$SOURCE" ]; do
        SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"
        SOURCE="$(readlink "$SOURCE")"
        [[ $SOURCE != /* ]] && SOURCE="$SCRIPT_DIR/$SOURCE"
    done
    SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" >/dev/null 2>&1 && pwd )"
    echo "$SCRIPT_DIR"
}

# 初始化路径
init_paths() {
    SCRIPT_DIR=$(get_script_dir)
    CORE_FUNCTIONS_DIR="${SCRIPT_DIR}/Corefunctions"
    CONFIG_DIR="${SCRIPT_DIR}/deb_config"
    LOG_DIR="${CONFIG_DIR}/logs"
    TEMPLATES_DIR="${CONFIG_DIR}/templates"
    PROJECTS_DIR="${SCRIPT_DIR}/DEB_Projects"
}

# 检查并创建目录
init_dirs() {
    mkdir -p "${CONFIG_DIR}" "${LOG_DIR}" "${TEMPLATES_DIR}" "${PROJECTS_DIR}" || {
        echo -e "${RED}无法创建必要目录${NC}"
        exit 1
    }
}

# 加载配置文件
load_config() {
    local config_files=(
        "${SCRIPT_DIR}/configuration.sh"
        "${SCRIPT_DIR}/../configuration.sh"
        "${CONFIG_DIR}/configuration.sh"
    )
    
    for config in "${config_files[@]}"; do
        if [ -f "$config" ]; then
            source "$config" && return 0
        fi
    done
    
    echo -e "${RED}致命错误：找不到配置文件${NC}"
    exit 1
}

# 加载核心功能
load_core_functions() {
    if [ ! -d "${CORE_FUNCTIONS_DIR}" ]; then
        echo -e "${YELLOW}警告：找不到Corefunctions目录${NC}"
        return 1
    fi

    local subdirs=("Miscellaneous" "create" "edit" "check")
    for subdir in "${subdirs[@]}"; do
        local dir_path="${CORE_FUNCTIONS_DIR}/${subdir}"
        if [ -d "$dir_path" ]; then
            for f in "${dir_path}"/*.sh; do
                if [ -f "$f" ]; then
                    source "$f"
                fi
            done
        fi
    done
}

# 加载用户界面
load_ui() {
    local ui_files=(
        "${SCRIPT_DIR}/Userinterface.sh"
        "${SCRIPT_DIR}/../Userinterface.sh"
        "${CONFIG_DIR}/Userinterface.sh"
    )
    
    for ui in "${ui_files[@]}"; do
        if [ -f "$ui" ]; then
            source "$ui" && return 0
        fi
    done
    
    echo -e "${RED}用户界面加载失败${NC}"
    exit 1
}

# 主函数
main() {
    init_paths
    init_dirs
    load_config
    load_core_functions
    load_ui
    
    echo -e "${GREEN}=== 越狱DEB工具 v7.0 ===${NC}"
    echo -e "运行路径: ${SCRIPT_DIR}"
    show_main_menu
}

# 执行入口
main "$@"